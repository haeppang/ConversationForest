var createError = require("http-errors")
var express = require("express")
var path = require("path")
var cookieParser = require("cookie-parser")
var logger = require("morgan")
var indexRouter = require("./routes/index")
var app = express()
var mysql = require("mysql")
var fs = require("fs")
const { JSDOM } = require("jsdom")
const { window } = new JSDOM("")
const $ = require("jquery")(window)
const superagent = require("superagent")
const moment = require("moment")

// view engine setup
app.set("views", path.join(__dirname, "views"))
app.set("view engine", "pug")

app.use(logger("dev"))
app.use(express.json())
app.use(express.urlencoded({ extended: false }))
app.use(cookieParser())
app.use(express.static(path.join(__dirname, "public")))

app.use("/", indexRouter)


app.get("/onloadEnvir", function (req, res) {
  var connection = mysql.createConnection({
    host: "phenome.iptime.org",
    port: "63306",
    user: "oogis",
    password: "oogis320",
    database: "Enviromental"
})
  var sql = "SELECT from_unixtime(`time@timestamp`, '%Y-%m-%d %H:%i:%s') AS times, data_format_0, data_format_1, data_format_2, data_format_3\
  FROM Enviromental.`GMOCMT_Inside Data_data` where from_unixtime(`time@timestamp`, '%Y-%m-%d %H:%i:%s') > date_add(now(), interval - 1 day);"

  connection.query(sql, function(err, data) {
    if (err) throw err;
    connection.end();
    res.send(data);
  })
})


app.get("/searchFile", function (req, res) {
  var base_folder = "/mnt/hdd1/temp"
  var folder = req.query.folder
  var id = req.query.id

  fs.readdir(path.join(base_folder, folder), function (err, filelist) {
    if (err) throw err

    var fsData = []
    $.each(filelist, function (i, data) {
      if (fs.lstatSync(path.join(base_folder, folder, data)).isDirectory()) {
        fsData.unshift({
          text: data,
          href: path.join(folder, data),
          nodes: [],
        })
      } else {
        if ((path.extname(data) == ".png" || path.extname(data) == ".jpg") && id == "treeview_info") {
          fsData.push({
            text: data,
            href: path.join(folder, data),
          })
        }
        else if (path.extname(data) == ".csv" && id != "treeview_info") {
          fsData.push({
            text: data,
            href: path.join(folder, data),
          })
        }
      }
    })
    res.send(fsData)
  })
})


app.post('/Upload_Data', function(req, res) {
  // mySQL Connection
  var connection = mysql.createConnection({
      host: "phenome.iptime.org",
      port: "23306",
      user: "choi",
      password: "1518",
      database: "CropDisaster"
  })
  var species = req.body.species;
  var res_purpose = req.body.res_purpose;
  var res_type = req.body.res_type;
  var admin = req.body.admin;
  var res_stdate = req.body.res_stdate;
  var res_eddate = req.body.res_eddate;
  var res_name = req.body.res_name;
  var type = req.body.type;
  var nodes = JSON.parse(req.body.node);

  console.log(nodes);
  superagent.post('192.168.0.97:8080/move')
      .query({ species:req.body.species,
          res_purpose:req.body.res_purpose,
          res_type:req.body.res_type,
          res_admin:req.body.admin,
          res_stdate:req.body.res_stdate,
          res_eddate:req.body.res_eddate,
          res_name:req.body.res_name,
          type:req.body.type,
          'nodes':req.body.node
       })
      .end((err, res) => {
      if (err) console.log(err);
  });
})


app.get("/getResearch", function (req, res) {
  var name = req.query.name;
  var admin = req.query.admin;
  var stdate = req.query.res_stdate;
  var eddate = req.query.res_eddate;

  var sql = "SELECT * FROM Research"
  if (name != (undefined || "") || admin != (undefined || "") || stdate != (undefined || "") || eddate != (undefined || "")) {
        sql += " WHERE " + (admin == (undefined || "") ? "" : ("res_admin = '" + admin + "'")) +
            (name == (undefined || "") ? "" : (admin != (undefined || "") ? (" AND res_name = '" + name + "'") : (" res_name = '" + name + "'")));


        if (stdate == (undefined || "")) "";
        else {
            if (admin != (undefined || "") || name != (undefined || "")) sql += " AND ";
            sql += "res_stdate >= '" + stdate + "'";
        }

        if (eddate == (undefined || "")) "";
        else {
            if (admin != (undefined || "") || name != (undefined || "") || stdate == (undefined || "")) sql += " AND ";;
            sql += "res_eddate <= '" + eddate + "'";
        }
    }
    var connection = mysql.createConnection({
      host: "phenome.iptime.org",
      port: "23306",
      user: "choi",
      password: "1518",
      database: "CropDisaster"
    })

    connection.query(sql, function(err, data) {
        if (err) throw err;
        connection.end();
        res.send(data);
    });
})


app.get('/onloadTable', (req, res) => {
  // mySQL Connection
  var connection = mysql.createConnection({
      host: "phenome.iptime.org",
      port: "23306",
      user: "choi",
      password: "1518",
      database: "CropDisaster"
  })

  var res_type = req.query.res_type;
  var admin = req.query.admin;
  var res_stdate = req.query.res_stdate;
  var res_eddate = req.query.res_eddate;
  var sql = "SELECT * FROM Research"

  if (res_type != (undefined || "0") || admin != (undefined || "") ||
      res_stdate != (undefined || "") || res_eddate != (undefined || "")) {
      sql += " WHERE " +
          (admin == (undefined || "") ? "" : ("res_admin = '" + admin + "'")) +
          (res_type == (undefined || "0") ? "" : (admin != (undefined || "") ? (" AND res_type = '" + res_type + "'") : (" res_type = '" + res_type + "'")));


      if (res_stdate == (undefined || "")) "";
      else {
          if (admin != (undefined || "") || res_type != (undefined || "0")) sql += " AND ";
          sql += "res_stdate >= '" + res_stdate + "'";
      }

      if (res_eddate == (undefined || "")) "";
      else {
          if (admin != (undefined || "") || res_type != (undefined || "0") || res_stdate == (undefined || "")) sql += " AND ";;
          sql += "res_eddate <= '" + res_eddate + "'";
      }
  }

  connection.query(sql, function(err, data) {
      if (err) throw err;
      connection.end();
      res.send(data);
  });
});



app.get("/GetMask", function (req, res) {
  //이미지 처리 서버에 선택한 색상 영역만 가시화한 이미지를 생성 요청
  superagent
    .post("192.168.0.97:8000/masking")
    .query({ image: req.query.image, mask: req.query.mask, hmin: req.query.hmin, hmax: req.query.hmax, savedir: path.join(__dirname, "public", "images"), resize: req.query.resize })
    .end((err, result) => {
      console.log(result)
      if (err) console.log(err)
      else res.send(path.join("images", result.body.filename))
    })
})

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404))
})

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message
  res.locals.error = req.app.get("env") === "development" ? err : {}

  // render the error page
  res.status(err.status || 500)
  res.render("error")
})

function DeleteFile() {
  //이미지 처리 서버에서 생성한 이미지를 1일 간격으로 삭제
  fs.readdir(path.join(base_folder, "public", "images"), function (err, filelist) {
    if (err) throw err
    curTime = moment()
    $.each(filelist, function (i, data) {
      fileTime = moment(data.split("_")[0], "YYYYMMDDHHmmSS")
      if (curTime.diff(fileTime, "days") > 0) {
        fs.unlink(data)
      }
    })
  })
}

setTimeout(DeleteFile, 3600000)
module.exports = app
